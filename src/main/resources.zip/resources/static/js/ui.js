//http://ourcodeworld.com/articles/read/37/how-to-create-your-own-javascript-library
(function(window) {

	console.log('spring ui...');
	_viewguid = Cookies.get('VIEW_GUID');
	Cookies.remove('VIEW_GUID'); //clear
	console.log('_viewguid = ' + _viewguid);

	function springUi() {
		var _springUiObject = {};
		var AMP = '&';

		//TODO osobno id do rerenderowania, applyRequest, processowania
		_springUiObject.load = function(options) {
			var defaults = {
				showLoading : false,
				ids : [],
				params : '',
				serialize : function(id) {
					return $('#' + id).find('select, textarea, input').serialize();
				}
			}
			var settings = $.extend({}, defaults, options);

			var ids = jQuery.param({
				"id" : settings.ids
			});
			console.log('settings:' + settings)
			console.log('str: ' + ids)

			$.each(settings.ids, function(i, item) {
				console.log("item: " + item);
				settings.params = settings.params + AMP + settings.serialize(item);


			});

			//append componet ids
			settings.params = settings.params + AMP + ids;
			//append view id
			settings.params = settings.params + AMP + 'viewguid=' + _viewguid;


			console.log(settings.params);
			//[{id:x,js:x, html:x}]
			$.ajax({
				type : 'POST',
				url : '/ajax',
				data : settings.params,
				dataType : 'json',
				success : function(data) {
					console.log("ajax resonse: ");
					console.log(data);
					$.each(data, function(index, element) {

						console.log("refreshing: " + element.id);
						console.log("js: " + element.js);
						console.log("html: " + element.html);

						$('#' + element.id).html(element.html);
						eval(element.js); //?

					//$('body').append($('<div>', {
					//	text : element.name
					//}));
					});
				},

				error : function(request, status, error) {
					jsonValue = jQuery.parseJSON(request.responseText);
					alert(jsonValue.error + " : " + jsonValue.message);
				}
			});
		};

		return _springUiObject;
	}

	// We need that our library is globally accesible, then we save in the window
	if (typeof (window.Ui) === 'undefined') {
		window.Ui = springUi();
	}
})(window);

//Ui.load();